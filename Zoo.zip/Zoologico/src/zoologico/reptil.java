/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoologico;

/**
 *
 * @author estudiantes
 */
public class reptil {
    private int diasGestacion;
    private String tipoPrenez;
    private int numCrias;
    private int numPartos;

    /**
     * Construct method .
     * @param diasGestacion
     * @param tipoPrenez
     * @param numCrias
     * @param numPartos 
     */
    public reptil(int diasGestacion,int numCrias, String tipoPrenez, int numPartos){
        this.diasGestacion = diasGestacion;
        this.tipoPrenez = tipoPrenez;
        this.numCrias = numCrias;
        this.numPartos = numPartos;        
    }
    /**
     * @return the diasGestacion
     */
    public int getDiasGestacion() {
        return diasGestacion;
    }

    /**
     * @param diasGestacion the diasGestacion to set
     */
    public void setDiasGestacion(int diasGestacion) {
        this.diasGestacion = diasGestacion;
    }

    /**
     * @return the tipoPrenez
     */
    public String getTipoPreñez() {
        return tipoPrenez;
    }

    /**
     * @param tipoPrenez the tipoPrenez to set
     */
    public void setTipoPreñez(String tipoPrenez) {
        this.tipoPrenez = tipoPrenez;
    }

    /**
     * @return the numCrias
     */
    public int getNumCrias() {
        return numCrias;
    }

    /**
     * @param numCrias the numCrias to set
     */
    public void setNumCrias(int numCrias) {
        this.numCrias = numCrias;
    }

    /**
     * @return the numPartos
     */
    public int getNumPartos() {
        return numPartos;
    }

    /**
     * @param numPartos the numPartos to set
     */
    public void setNumPartos(int numPartos) {
        this.numPartos = numPartos;
    }
}
