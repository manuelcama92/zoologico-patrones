package zoologico;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author estudiantes
 */
public class Mamifero {
    
    private int diasGestacion;
    
    private int numeroCrias;
    
    private String tipoPrenez;
    
    private int numeroPartos;
    
    public Mamifero(int diasGestacion, int numeroCrias, String tipoPrenez, int numeroPartos){
        
        this.diasGestacion = diasGestacion;
        this.numeroCrias = numeroCrias;
        this.tipoPrenez = tipoPrenez;
        this.numeroPartos = numeroPartos;               
    }

    /**
     * @return the diasGestacion
     */
    public int getDiasGestacion() {
        return diasGestacion;
    }

    /**
     * @param diasGestacion the diasGestacion to set
     */
    public void setDiasGestacion(int diasGestacion) {
        this.diasGestacion = diasGestacion;
    }

    /**
     * @return the numeroCrias
     */
    public int getNumeroCrias() {
        return numeroCrias;
    }

    /**
     * @param numeroCrias the numeroCrias to set
     */
    public void setNumeroCrias(int numeroCrias) {
        this.numeroCrias = numeroCrias;
    }

    /**
     * @return the tipoPrenez
     */
    public String getTipoPrenez() {
        return tipoPrenez;
    }

    /**
     * @param tipoPrenez the tipoPrenez to set
     */
    public void setTipoPrenez(String tipoPrenez) {
        this.tipoPrenez = tipoPrenez;
    }

    /**
     * @return the numeroPartos
     */
    public int getNumeroPartos() {
        return numeroPartos;
    }

    /**
     * @param numeroPartos the numeroPartos to set
     */
    public void setNumeroPartos(int numeroPartos) {
        this.numeroPartos = numeroPartos;
    }
    
   
    
}
