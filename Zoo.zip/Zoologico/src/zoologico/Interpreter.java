package zoologico;

public class Interpreter {
    
    private int entrada;
    
    public Interpreter(int entrada){
    
        this.entrada = entrada;
    }

    public int getEntrada() {
        return entrada;
    }

    public void setEntrada(int entrada) {
        this.entrada = entrada;
    }
    
    santuario s = new santuario();
    
    public void Interpretar(int entrada){
     
            s.getnumAnimales();
            s.getMamiferos();
            s.getReptiles();
            s.gethijosParto();

        }
        
    }
    

