package zoologico;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Zoologico {
    
    public static void main(String[] args)throws IOException {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Selecciona el tipo de animal:\n1. Mamifero \n2. Reptil\n");  
        
        String entrada = br.readLine();  
    }
    
    Mamifero m = new Mamifero(180,5,"Viviparo",1);

        public int getnumAnimales(){
        
           return m.getNumeroCrias()*m.getNumeroPartos();
        }
}
