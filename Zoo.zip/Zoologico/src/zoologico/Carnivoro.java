package zoologico;

public class Carnivoro {
    
    private int cantidadComida;
    private int peso;

    public Carnivoro(int cantidadComida, int peso){
    this.peso = peso;
    this.cantidadComida = cantidadComida;
    }
    /**
     * @return the cantidadComida
     */
    public int getCantidadComida() {
        return cantidadComida;
    }

    /**
     * @param cantidadComida the cantidadComida to set
     */
    public void setCantidadComida(int cantidadComida) {
        this.cantidadComida = cantidadComida;
    }

    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }
    
}
