/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoologico;

/**
 * Facade .
 * @author estudiantes
 */

public class santuario {
    
    private static santuario sant; 
    
    private static santuario getInstance(){
        if(sant == null){
            sant = new santuario();
            return sant;
        }
        else{
            return sant;
        }
    }       
    Mamifero m = new Mamifero(180,5,"Viviparo",1);
    reptil r = new reptil(180,5,"Oviparo",1);

        public int getnumAnimales(){
            getInstance();
           return m.getNumeroCrias()*m.getNumeroPartos() + r.getNumPartos()*r.getNumCrias();
        }  
        
        public int getReptiles(){
            getInstance();
           return r.getNumPartos()*r.getNumCrias();
        } 
        
        public int getMamiferos(){
            getInstance();
           return m.getNumeroCrias()*m.getNumeroPartos();
        } 
        
        public int gethijosParto(){
            getInstance();
           return m.getNumeroPartos()+r.getNumPartos();
        }         
}
